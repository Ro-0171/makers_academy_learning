import UIKit

//let randomInt = Int.random(in: 1..<6)
//
//if randomInt == 1 {
//    print("One")
//} else if randomInt == 2 {
//    print("Two")
//}else {
//    print("More")
//}


let roles = ["doctor", "nurse", "patient", "driver", "plumber"]
var role = roles.randomElement()

switch role {
case "doctor":
    print("Please go to the second floor")
case "nurse":
    print("Please go to the first floor")
case "patient":
    print("Please go to the waiting room")
default:
    print("Please go to the reception")
}

let randomInt = Int.random(in: 1..<101)

if randomInt % 3 == 0 && randomInt % 5 == 0 {
    print("FizzBuzz")
} else if randomInt % 3 == 0 {
    print("Fizz")
} else if randomInt % 5 == 0 {
    print("Buzz")
} else {
    print(randomInt)
}

