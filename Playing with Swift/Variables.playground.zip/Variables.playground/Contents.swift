import UIKit

let greeting = "Hello, playground!";

var introduction = " My name is Reece";

print(greeting + introduction);

