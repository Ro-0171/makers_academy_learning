import UIKit

class Introducer {
    let introducer: String
    
    init(introducer: String) {
        self.introducer = introducer
    }
    func  announce() -> String {
        return "I am \(introducer)!"
    }
    func introduce(who: String) -> String {
        return "Hello \(who), I am \(introducer)!"
    }
}

var introducer = Introducer(introducer: "Reece")

print(introducer.announce())
print(introducer.introduce(who: "Tara"))


class Reminder {
    
}
