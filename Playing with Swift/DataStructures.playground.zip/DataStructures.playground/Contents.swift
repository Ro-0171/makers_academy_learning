import UIKit

var myList = ["Cat", "Mouse", "Frog"]

myList.append("Lynx")

print(myList)

let myAnimals = ["Cat", "cat", "frog", "cat", "dog", "Dog"]
var counters = [String: Int]()

for animal in myAnimals {
    counters[animal.lowercased(), default: 0] += 1
}

print(counters)


var countryCounts = [Character: Int]()

var myCountries = ["Australia", "Japan", "USA", "United Kingdom", "Spain", "Switzerland", "Germany"]

for country in myCountries {
    let lowercaseCountry = country.lowercased()
    if let firstLetter = lowercaseCountry.first {
        if countryCounts[firstLetter] == nil {
            countryCounts[firstLetter] = 1
        } else {
            countryCounts[firstLetter]! += 1
        }
    }
}
print(countryCounts)

