import UIKit

var petNickname: String? = "Uno"

func greetPet(_ nickname: String?) {
    if let nickname = nickname {
        print("Hello \(nickname)!")
    } else {
        print("Hello Nova!")
    }
}

greetPet(petNickname)
greetPet(nil)


func printFavouriteBookDetails(title: String, description: String?, reason: String?){

print("Title: \"\(title)\"")
    
    if let description = description {
        print("Description: \(description)")
    }
    
    guard let reason = reason else {
        return
    }
    
    print("Reason: \(reason)")
}

printFavouriteBookDetails(title: "Hot Milk", description: "A vibrant and starkly humorous tale of a mother-daughter relationship and the complexities of identity.", reason: "It's a compelling exploration of the human psyche and personal transformation.")

printFavouriteBookDetails(title: "Hot Milk", description: "A vibrant and starkly humorous tale of a mother-daughter relationship and the complexities of identity.", reason: nil)
