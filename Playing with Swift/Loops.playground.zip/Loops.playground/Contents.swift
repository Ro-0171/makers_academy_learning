import UIKit

//for number in 2341...34325 {
//    print(number) }

var sumEven = 0

for number in 2341...34325 {
    if number % 2 == 0 {
        sumEven += number
    }
}

print(sumEven)

func factorial(_ n: Int) -> Int {
    var result = 1
    for i in 1...n {
        result *= i
    }
    return result
}

var number = 17
let result = factorial(number)
print("Factorial of \(number) is \(result)")
