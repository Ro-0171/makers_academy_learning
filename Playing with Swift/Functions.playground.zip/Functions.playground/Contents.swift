import UIKit

func addFive(_ number: Int) -> Int {
    return number + 5
}

print(addFive(4))
print(addFive(2132))

func subtractLowFromHigh(_ num1: Int, _ num2: Int) -> Int {
    if num1 > num2 {
        return num1 - num2
} else {
    return num2 - num1
    }
}

print(subtractLowFromHigh(2, 3))
print(subtractLowFromHigh(3, 2))
print(addFive(subtractLowFromHigh(1463, 16475)))
